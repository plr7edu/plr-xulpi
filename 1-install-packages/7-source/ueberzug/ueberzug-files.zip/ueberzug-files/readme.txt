sudo apt install libxext-dev libx11-dev -y
git clone --depth 1 --branch 18.1.9 https://github.com/seebye/ueberzug.git
cd ueberzug
python3 setup.py install
